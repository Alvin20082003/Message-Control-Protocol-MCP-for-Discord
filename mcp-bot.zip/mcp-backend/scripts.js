// DOM Elements
const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');
const searchButton = document.querySelector('#content nav form .form-input button');
const searchButtonIcon = document.querySelector('#content nav form .form-input button .bx');
const searchForm = document.querySelector('#content nav form');
const switchMode = document.getElementById('switch-mode');
const contentSections = document.querySelectorAll('.content-section');
const navLinks = document.querySelectorAll('#sidebar .side-menu.top li a');
const dropdownToggle = document.querySelector('.profile .dropdown-toggle');
const dropdownMenu = document.querySelector('.profile .dropdown-menu');
const logoutBtn = document.getElementById('logout-btn');
const editProfileBtn = document.getElementById('editProfileBtn');
const editProfileForm = document.getElementById('editProfileForm');
const changeAvatarBtn = document.getElementById('changeAvatarBtn');
const removeAvatarBtn = document.getElementById('removeAvatarBtn');
const avatarUpload = document.getElementById('avatarUpload');
const avatarPreview = document.getElementById('avatarPreview');
const profileAvatar = document.getElementById('profileAvatar');
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const addUserBtn = document.getElementById('add-user-btn');
    const addUserModal = document.getElementById('addUserModal');
    const closeModalBtns = document.querySelectorAll('.close, .close-btn');
    const saveUserBtn = document.getElementById('saveUserBtn');
    const submitActionBtn = document.getElementById('submit-action-btn');
    const userActionContainer = document.getElementById('user-action-container');
    const moderationTableBody = document.getElementById('moderation-table-body');

    // Modal Functions
    function openModal() {
        addUserModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        addUserModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    // Event Listeners for Modal
    if (addUserBtn) {
        addUserBtn.addEventListener('click', function(e) {
            e.preventDefault();
            openModal();
        });
    }

    if (closeModalBtns) {
        closeModalBtns.forEach(btn => {
            btn.addEventListener('click', closeModal);
        });
    }

    window.addEventListener('click', function(e) {
        if (e.target === addUserModal) {
            closeModal();
        }
    });

    // Save New User
    if (saveUserBtn) {
        saveUserBtn.addEventListener('click', function() {
            const username = document.getElementById('newUsername').value.trim();
            const userId = document.getElementById('newUserID').value.trim();
            const email = document.getElementById('newUserEmail').value.trim();
            const avatar = document.getElementById('newUserAvatar').value.trim();

            if (!username || !userId) {
                alert('Username and User ID are required!');
                return;
            }

            // Create new user option
            const userOption = {
                value: `${username}#${userId}`,
                text: `${username}#${userId}`,
                avatar: avatar || 'pngtree-administrator-admin-avatar-png-image_16031558.png'
            };

            // Add to all select dropdowns
            document.querySelectorAll('.user-select').forEach(select => {
                const option = new Option(userOption.text, userOption.value);
                option.dataset.avatar = userOption.avatar;
                select.add(option);
            });

            // Reset form and close modal
            document.getElementById('newUserForm').reset();
            closeModal();

            // Add new action form if first user
            if (document.querySelectorAll('.user-action').length === 1) {
                addUserActionForm();
            }
        });
    }

    // Add New User Action Form
    function addUserActionForm() {
        const newActionForm = document.createElement('div');
        newActionForm.className = 'user-action';
        newActionForm.innerHTML = `
            <div class="form-group">
                <label>Select User</label>
                <select class="user-select">
                    <option value="">-- Select User --</option>
                </select>
            </div>
            <div class="form-group">
                <label>Action Type</label>
                <select class="action-type">
                    <option value="warn">Warning</option>
                    <option value="mute">Mute</option>
                    <option value="kick">Kick</option>
                    <option value="ban">Ban</option>
                </select>
            </div>
            <div class="form-group">
                <label>Reason</label>
                <textarea class="reason" placeholder="Enter reason for action..."></textarea>
            </div>
        `;

        // Copy existing user options
        const firstSelect = document.querySelector('.user-select');
        const newSelect = newActionForm.querySelector('.user-select');
        
        Array.from(firstSelect.options).forEach(option => {
            if (option.value) {
                const newOption = new Option(option.text, option.value);
                newOption.dataset.avatar = option.dataset.avatar;
                newSelect.add(newOption);
            }
        });

        userActionContainer.appendChild(newActionForm);
    }

    // Submit Actions
    if (submitActionBtn && moderationTableBody) {
        submitActionBtn.addEventListener('click', function() {
            const userActions = document.querySelectorAll('.user-action');
            const currentDate = new Date();
            const formattedDate = formatDate(currentDate);
            
            let hasErrors = false;
            const newRows = [];

            userActions.forEach(action => {
                const userSelect = action.querySelector('.user-select');
                const actionType = action.querySelector('.action-type');
                const reason = action.querySelector('.reason');
                
                // Validation
                if (!userSelect || !userSelect.value) {
                    alert('Please select a user for all actions');
                    hasErrors = true;
                    return;
                }
                
                if (!reason || !reason.value.trim()) {
                    alert('Please enter a reason for all actions');
                    hasErrors = true;
                    return;
                }

                if (hasErrors) return;
                
                // Create table row
                const actionData = {
                    user: userSelect.value,
                    avatar: userSelect.options[userSelect.selectedIndex].dataset.avatar,
                    action: actionType.value,
                    reason: reason.value.trim(),
                    date: formattedDate
                };
                
                newRows.push(createModerationRow(actionData));
            });
            
            if (hasErrors) return;
            
            // Add all new rows to table
            newRows.forEach(row => {
                moderationTableBody.prepend(row);
            });

            // Reset forms
            resetActionForms();
            
            // Show success message
            showAlert('Actions submitted successfully!', 'success');
        });
    }

    // Helper Functions
    function formatDate(date) {
        const pad = num => num.toString().padStart(2, '0');
        return `${pad(date.getDate())}-${pad(date.getMonth()+1)}-${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
    }

    function createModerationRow(data) {
        const actionTexts = {
            'warn': 'Warning',
            'mute': 'Mute',
            'kick': 'Kick',
            'ban': 'Ban'
        };
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <img src="${data.avatar}" alt="${data.user}">
                <p>AdminUser</p>
            </td>
            <td><span class="badge ${data.action}">${actionTexts[data.action]}</span></td>
            <td>${data.user}</td>
            <td>${data.reason}</td>
            <td>${data.date}</td>
        `;
        return row;
    }

    function resetActionForms() {
        // Keep only the first form
        while (userActionContainer.children.length > 1) {
            userActionContainer.removeChild(userActionContainer.lastChild);
        }
        
        // Reset first form
        const firstForm = userActionContainer.firstElementChild;
        if (firstForm) {
            const firstSelect = firstForm.querySelector('.user-select');
            const firstActionType = firstForm.querySelector('.action-type');
            const firstReason = firstForm.querySelector('.reason');
            
            if (firstSelect) firstSelect.value = '';
            if (firstActionType) firstActionType.value = 'warn';
            if (firstReason) firstReason.value = '';
        }
    }

    function showAlert(message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        const main = document.querySelector('main');
        if (main) {
            main.insertBefore(alert, main.firstChild);
            
            // Remove after 3 seconds
            setTimeout(() => {
                alert.remove();
            }, 3000);
        }
    }
});
// Function to show selected section
function showSection(section) {
    document.querySelectorAll('.settings-section').forEach(sec => sec.classList.add('hidden'));
    document.getElementById(section).classList.remove('hidden');

    document.querySelectorAll('.settings-sidebar li').forEach(item => item.classList.remove('active'));
    event.target.classList.add('active');
}

// Dark Mode Toggle
document.getElementById("darkModeToggle").addEventListener("change", function() {
    document.body.classList.toggle("dark-mode");
});

function saveProfile() {
    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    alert("Profile Updated!\nUsername: " + username + "\nEmail: " + email);
}

function changePassword() {
    let currentPassword = document.getElementById("currentPassword").value;
    let newPassword = document.getElementById("newPassword").value;
    
    if (currentPassword === "" || newPassword === "") {
        alert("Please fill out both password fields.");
        return;
    }
    
    alert("Password updated successfully!");
}

document.getElementById("darkModeToggle").addEventListener("change", function() {
    document.body.classList.toggle("dark-mode");
});

document.querySelector('a[href="#moderation-logs"]').addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('moderation-logs').scrollIntoView({ behavior: 'smooth' });
});


// Sidebar menu active state
allSideMenu.forEach(item => {
    const li = item.parentElement;

    item.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all menu items
        allSideMenu.forEach(i => {
            i.parentElement.classList.remove('active');
        });
        
        // Add active class to clicked menu item
        li.classList.add('active');
        
        // Show the corresponding content section
        const targetId = this.getAttribute('href').substring(1);
        showContentSection(targetId);
    });
});

// Toggle sidebar
menuBar.addEventListener('click', function() {
    sidebar.classList.toggle('hide');
    
    // Store sidebar state in localStorage
    localStorage.setItem('sidebarState', sidebar.classList.contains('hide') ? 'hidden' : 'visible');
});

// Mobile search functionality
searchButton.addEventListener('click', function(e) {
    if(window.innerWidth < 768) {
        e.preventDefault();
        searchForm.classList.toggle('show');
        if(searchForm.classList.contains('show')) {
            searchButtonIcon.classList.replace('bx-search', 'bx-x');
        } else {
            searchButtonIcon.classList.replace('bx-x', 'bx-search');
        }
    }
});

// Dark/Light mode toggle
switchMode.addEventListener('change', function() {
    if(this.checked) {
        document.body.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    } else {
        document.body.classList.remove('dark');
        localStorage.setItem('theme', 'light');
    }
});

// Show specific content section
function showContentSection(sectionId) {
    contentSections.forEach(section => {
        section.classList.remove('active');
        if(section.id === sectionId) {
            section.classList.add('active');
        }
    });
    
    // Update browser history
    history.pushState(null, null, `#${sectionId}`);
    
    // Close sidebar on mobile after selection
    if(window.innerWidth < 768) {
        sidebar.classList.add('hide');
    }
}

// Profile dropdown functionality
if(dropdownToggle) {
    dropdownToggle.addEventListener('click', function(e) {
        e.preventDefault();
        dropdownMenu.classList.toggle('show');
    });
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    if(!e.target.closest('.profile')) {
        if(dropdownMenu) dropdownMenu.classList.remove('show');
    }
});

// Logout functionality
if(logoutBtn) {
    logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        // Add your logout logic here
        console.log('Logging out...');
        window.location.href = 'login.html'; // Redirect to login page
    });
}

// Edit profile toggle
if(editProfileBtn) {
    editProfileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        editProfileForm.classList.toggle('hidden');
    });
}

// Avatar upload functionality
if(changeAvatarBtn) {
    changeAvatarBtn.addEventListener('click', function(e) {
        e.preventDefault();
        avatarUpload.click();
    });
}

if(avatarUpload) {
    avatarUpload.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if(file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                avatarPreview.src = event.target.result;
                profileAvatar.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
}

// Remove avatar
if(removeAvatarBtn) {
    removeAvatarBtn.addEventListener('click', function(e) {
        e.preventDefault();
        avatarPreview.src = 'img/default-avatar.png';
        profileAvatar.src = 'img/default-avatar.png';
    });
}

// Initialize dashboard
function initDashboard() {
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if(savedTheme === 'dark') {
        document.body.classList.add('dark');
        if(switchMode) switchMode.checked = true;
    }
    
    // Check for saved sidebar state
    const sidebarState = localStorage.getItem('sidebarState');
    if(sidebarState === 'hidden' || window.innerWidth < 768) {
        sidebar.classList.add('hide');
    }
    
    // Show the correct content section based on URL hash
    const hash = window.location.hash.substring(1);
    const defaultSection = hash || 'dashboard';
    showContentSection(defaultSection);
    
    // Set active menu item based on current section
    navLinks.forEach(link => {
        if(link.getAttribute('href') === `#${defaultSection}`) {
            link.parentElement.classList.add('active');
        } else {
            link.parentElement.classList.remove('active');
        }
    });
    
    // Initialize charts (if you have them)
    initCharts();
}

// Initialize charts (example with Chart.js)
function initCharts() {
    if (typeof Chart === 'undefined') return;

    // User Activity Chart
    const activityCtx = document.getElementById('activityChart');
    if (activityCtx) {
        new Chart(activityCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [
                    {
                        label: 'Active Users',
                        data: [1200, 1900, 1700, 2000, 2200, 2500],
                        borderColor: '#7380ec',
                        backgroundColor: 'rgba(115, 128, 236, 0.1)',
                        tension: 0.1,
                        fill: true
                    },
                    {
                        label: 'New Users',
                        data: [300, 450, 400, 600, 700, 800],
                        borderColor: '#4caf50',
                        backgroundColor: 'rgba(76, 175, 80, 0.1)',
                        tension: 0.1,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return `${context.dataset.label}: ${context.raw} users`;
                            }
                        }
                    }
                }
            }
        });
    }

    // Moderation Actions Chart
    const moderationCtx = document.getElementById('moderationChart');
    if (moderationCtx) {
        new Chart(moderationCtx, {
            type: 'bar',
            data: {
                labels: ['Bans', 'Warnings', 'Mutes', 'Kicks'],
                datasets: [{
                    label: 'Moderation Actions',
                    data: [12, 19, 8, 5],
                    backgroundColor: ['#db504a', '#ffce26', '#fd7238', '#3c91e6'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
}

window.onload = initCharts;
// Handle window resize
function handleResize() {
    if(window.innerWidth > 576) {
        if(searchButtonIcon) searchButtonIcon.classList.replace('bx-x', 'bx-search');
        if(searchForm) searchForm.classList.remove('show');
    }
    
    // Auto-hide sidebar on smaller screens
    if(window.innerWidth < 768) {
        sidebar.classList.add('hide');
    } else {
        // Restore sidebar state if not on mobile
        const sidebarState = localStorage.getItem('sidebarState');
        if(sidebarState === 'visible') {
            sidebar.classList.remove('hide');
        }
    }
}

// Event listeners
window.addEventListener('DOMContentLoaded', initDashboard);
window.addEventListener('resize', handleResize);

// Handle back/forward navigation
window.addEventListener('popstate', function() {
    const hash = window.location.hash.substring(1);
    if(hash) {
        showContentSection(hash);
    }
    

    
});