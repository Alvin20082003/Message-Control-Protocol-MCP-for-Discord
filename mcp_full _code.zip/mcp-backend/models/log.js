const mongoose = require("mongoose");

const LogSchema = new mongoose.Schema({
    user: String,
    message: String,
    action: String,
    timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Log", LogSchema);
document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form submission

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const message = document.getElementById("message");

    // Dummy admin credentials (Replace this with real authentication logic)
    const adminData = {
        email: "admin@example.com",
        password: "admin123"
    };

    if (email === adminData.email && password === adminData.password) {
        // Store login session
        localStorage.setItem("isLoggedIn", "true");

        // Redirect to admin dashboard (index.html)
        window.location.href = "index.html";
    } else {
        message.textContent = "Invalid email or password!";
        message.style.color = "red";
    }
});

// Check if already logged in (to prevent accessing login page after login)
if (localStorage.getItem("isLoggedIn") === "true") {
    window.location.href = "index.html";
}
